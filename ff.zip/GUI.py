
import sys
import threading
import time
import LogicaNegocio 
from PyQt5.QtCore import (QCoreApplication, QMetaObject, QObject, QPoint,
    QRect, QSize, QUrl, Qt)
from PyQt5.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont,
    QFontDatabase, QIcon, QLinearGradient, QPalette, QPainter, QPixmap,
    QRadialGradient)
from PyQt5.QtWidgets import *



class Ui_Form(QWidget):
    def __init__ (self):
        super(Ui_Form, self).__init__()
        self.pushButton = QPushButton(self)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(10, 10, 111, 23))
        self.pushButton_2 = QPushButton(self)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(120, 10, 111, 23))
        self.pushButton_3 = QPushButton(self)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(230, 10, 111, 23))
        self.pushButton_4 = QPushButton(self)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setGeometry(QRect(340, 10, 111, 23))
        self.label = QLabel(self)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(20, 107, 171, 21))
        self.label_2 = QLabel(self)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(20, 137, 161, 16))
        self.lineEdit = QLineEdit(self)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setGeometry(QRect(190, 107, 101, 20))
        self.label_3 = QLabel(self)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(20, 167, 151, 16))
        self.lineEdit_2 = QLineEdit(self)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setGeometry(QRect(190, 137, 41, 20))
        self.lineEdit_3 = QLineEdit(self)
        self.lineEdit_3.setObjectName(u"lineEdit_3")
        self.lineEdit_3.setGeometry(QRect(190, 167, 41, 20))
        self.label_4 = QLabel(self)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(240, 140, 47, 13))
        self.label_5 = QLabel(self)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(300, 110, 47, 13))
        self.comboBox = QComboBox(self)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setGeometry(QRect(240, 167, 71, 22))
        self.lineEdit_4 = QLineEdit(self)
        self.lineEdit_4.setObjectName(u"lineEdit_4")
        self.lineEdit_4.setGeometry(QRect(398, 167, 31, 20))
        self.label_6 = QLabel(self)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(320, 167, 81, 20))
        self.label_7 = QLabel(self)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(20, 197, 151, 16))
        self.lineEdit_5 = QLineEdit(self)
        self.lineEdit_5.setObjectName(u"lineEdit_5")
        self.lineEdit_5.setGeometry(QRect(190, 197, 101, 20))
        self.label_8 = QLabel(self)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(300, 200, 47, 13))
        self.label_9 = QLabel(self)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(20, 60, 391, 20))
        self.pushButton_5 = QPushButton(self)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setGeometry(QRect(20, 230, 75, 23))
        self.Lbl_respuesta_calculo = QLabel(self)
        self.Lbl_respuesta_calculo.setObjectName(u"Lbl_respuesta_calculo")
        self.Lbl_respuesta_calculo.setGeometry(QRect(20, 270, 431, 41))
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Lbl_respuesta_calculo.sizePolicy().hasHeightForWidth())
        self.Lbl_respuesta_calculo.setSizePolicy(sizePolicy)
        palette = QPalette()
        brush = QBrush(QColor(0, 0, 255, 255))
        brush.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Active, QPalette.WindowText, brush)
        palette.setBrush(QPalette.Inactive, QPalette.WindowText, brush)
        brush1 = QBrush(QColor(120, 120, 120, 255))
        brush1.setStyle(Qt.SolidPattern)
        palette.setBrush(QPalette.Disabled, QPalette.WindowText, brush1)
        self.Lbl_respuesta_calculo.setPalette(palette)
        self.Lbl_respuesta_calculo.setMouseTracking(True)
        self.Lbl_respuesta_calculo.setTabletTracking(False)
        self.Lbl_respuesta_calculo.setFocusPolicy(Qt.NoFocus)
        self.Lbl_respuesta_calculo.setTextFormat(Qt.AutoText)
        self.Lbl_respuesta_calculo.setTextInteractionFlags(Qt.NoTextInteraction)
        self.comboBox_2 = QComboBox(self)
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.setObjectName(u"comboBox_2")
        self.comboBox_2.setGeometry(QRect(435, 167, 61, 22))

        self.pushButton.setText(QCoreApplication.translate("Form", u"interes simpe", None))
        self.pushButton_2.setText(QCoreApplication.translate("Form", u"interes compuesto", None))
        self.pushButton_3.setText(QCoreApplication.translate("Form", u"comming soon", None))
        self.pushButton_4.setText(QCoreApplication.translate("Form", u"comming soon", None))
        self.label.setText(QCoreApplication.translate("Form", u"ingrese valor inicial del prestamo", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"ingrese el porcentaje de interes ", None))
        self.lineEdit.setText("")
        self.label_3.setText(QCoreApplication.translate("Form", u"ingrese el tiempo del prestamo ", None))
        self.lineEdit_2.setText("")
        self.lineEdit_3.setText("")
        self.label_4.setText(QCoreApplication.translate("Form", u"%", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"$", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("Form", u"dias", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("Form", u"meses", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("Form", u"a\u00f1os", None))
        self.comboBox.setItemText(3, QCoreApplication.translate("Form", u"trimestres", None))
        self.comboBox.setItemText(4, QCoreApplication.translate("Form", u"semestres", None))
        self.comboBox.setItemText(5, QCoreApplication.translate("Form", u"semanas", None))

        self.label_6.setText(QCoreApplication.translate("Form", u"tiempo restante", None))
        self.label_7.setText(QCoreApplication.translate("Form", u"valor final con intereses ", None))
        self.label_8.setText(QCoreApplication.translate("Form", u"$", None))
        self.label_9.setText(QCoreApplication.translate("Form", u"tenga en cuenta; que el valor que no agregue va a ser el valor a calcular", None))
        self.pushButton_5.setText(QCoreApplication.translate("Form", u"Calcular", None))
        self.Lbl_respuesta_calculo.setText("")
        self.comboBox_2.setItemText(0, QCoreApplication.translate("Form", u"dias", None))
        self.comboBox_2.setItemText(1, QCoreApplication.translate("Form", u"meses", None))
        self.comboBox_2.setItemText(2, QCoreApplication.translate("Form", u"a\u00f1os", None))
        self.comboBox_2.setItemText(3, QCoreApplication.translate("Form", u"trimestres", None))
        self.comboBox_2.setItemText(4, QCoreApplication.translate("Form", u"semestres", None))
        self.comboBox_2.setItemText(5, QCoreApplication.translate("Form", u"semanas", None))
    # retranslateUi


class Ui_Pagina_principal(QWidget):
    def __init__ (self):
        super(Ui_Pagina_principal, self).__init__()
        self.pushButton_1 = QPushButton(self)
        self.pushButton_1.setObjectName(u"pushButton")
        self.pushButton_1.setGeometry(QRect(10, 120, 111, 71))
        self.pushButton_2 = QPushButton(self)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(130, 120, 111, 71))
        self.pushButton_3 = QPushButton(self)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(250, 120, 111, 71))
        self.pushButton_4 = QPushButton(self)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setGeometry(QRect(370, 120, 111, 71))

        self.pushButton_1.setText(QCoreApplication.translate("Pagina_principal", u"interes simple", None))
        self.pushButton_2.setText(QCoreApplication.translate("Pagina_principal", u"interes compuesto", None))
        self.pushButton_3.setText(QCoreApplication.translate("Pagina_principal", u"Comming soon", None))
        self.pushButton_4.setText(QCoreApplication.translate("Pagina_principal", u"comming soon", None))
    # retranslateUi


class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.apilacion_widgets = QStackedWidget(self)
        self.pagina_principal = Ui_Pagina_principal()
        self.interes_simple = Ui_Form()
        self.apilacion_widgets.addWidget(self.pagina_principal)
        self.apilacion_widgets.addWidget(self.interes_simple)
        self.setCentralWidget(self.apilacion_widgets)
        self.apilacion_widgets.setCurrentWidget(self.pagina_principal)
        self.inicializar()

    def inicializar(self):
        self.resize (500,330)
        self.setWindowTitle("Ingenieria Economica")
        self.conexiones()
        self.interaccion_botones() 
        self.verificar_hilo = threading.Thread(target=self.verificacion_campos) 
        self.verificar_hilo.daemon = True  # Hacer que el hilo sea un demonio (se detendrá cuando se cierre la aplicación)
        self.verificar_hilo.start()    

    def conexiones(self):
        self.pagina_principal.pushButton_1.clicked.connect(self.cambio_interes_simple)
        

    def cambio_interes_simple(self):
        self.apilacion_widgets.setCurrentWidget(self.interes_simple)
        
    def interaccion_botones(self):
        self.interes_simple.pushButton_5.clicked.connect(self.actualizacion_resultado)

    def actualizacion_resultado(self):
        self.obtencion_datos()
        self.resultado = self.realizar_calculos()
        print(self.resultado)
        self.apilacion_widgets.setCurrentWidget(self.interes_simple.Lbl_respuesta_calculo.setText("el resultado de " + self.operacion + " es: " + str(self.resultado)))

    def obtencion_datos(self):
        if (self.interes_simple.lineEdit.text() != ""):
            self.capital = float(self.interes_simple.lineEdit.text())
        else:
            self.capital = 0

        if (self.interes_simple.lineEdit_2.text() != ""):
            self.tasa_interes = float(self.interes_simple.lineEdit_2.text())
        else:
            self.tasa_interes = 0
        
        if (self.interes_simple.lineEdit_3.text() != ""):
            self.tiempo_1 = float(self.interes_simple.lineEdit_3.text())
        else:
            self.tiempo_1 = 0
        

        if (self.interes_simple.lineEdit_4.text() != ""):
            self.tiempo_2 = float(self.interes_simple.lineEdit_4.text())
        else:
            self.tiempo_2 = 0

        self.cronograma_1 = self.interes_simple.comboBox.currentText()
        self.cronograma_2 = self.interes_simple.comboBox_2.currentText()

        if (self.interes_simple.lineEdit_5.text() != ""):
            self.intereses = float(self.interes_simple.lineEdit_5.text()) 
        else:
            self.intereses = 0
           

    def verificacion_campos(self):
        while True:
            if (self.interes_simple.lineEdit.text() == "" and self.interes_simple.lineEdit_2.text() != "" and self.interes_simple.lineEdit_3.text() != "" and self.interes_simple.lineEdit_5.text() != ""):
                self.interes_simple.lineEdit.setEnabled(False)
                self.operacion = "el capital"
            else:
                self.interes_simple.lineEdit.setEnabled(True)
            if (self.interes_simple.lineEdit.text() != "" and self.interes_simple.lineEdit_2.text() == "" and self.interes_simple.lineEdit_3.text() != "" and self.interes_simple.lineEdit_5.text() != ""):
                self.interes_simple.lineEdit_2.setEnabled(False)
                self.operacion = "la tasa de interes"
            else:
                self.interes_simple.lineEdit_2.setEnabled(True)
            if (self.interes_simple.lineEdit.text() != "" and self.interes_simple.lineEdit_2.text() != "" and self.interes_simple.lineEdit_3.text() == "" and self.interes_simple.lineEdit_5.text() != ""):
                self.interes_simple.lineEdit_3.setEnabled(False)
                self.interes_simple.comboBox.setEnabled(False)
                self.interes_simple.comboBox_2.setEnabled(False)
                self.interes_simple.lineEdit_4.setEnabled(False)
                self.operacion = "el tiempo"
            else:
                self.interes_simple.lineEdit_3.setEnabled(True)
                self.interes_simple.comboBox.setEnabled(True)
                self.interes_simple.comboBox_2.setEnabled(True)
                self.interes_simple.lineEdit_4.setEnabled(True)
            if (self.interes_simple.lineEdit.text() != "" and self.interes_simple.lineEdit_2.text() != "" and self.interes_simple.lineEdit_3.text() != "" and self.interes_simple.lineEdit_5.text() == ""):
                self.interes_simple.lineEdit_5.setEnabled(False)
                self.operacion = "los intereses"
            else:
                self.interes_simple.lineEdit_5.setEnabled(True)
            time.sleep(0.5)
    
    def realizar_calculos(self):  
        calculos = LogicaNegocio.InteresSimple()
        if (self.operacion == "el capital"):
            return calculos.hallar_valor_inicial(interes_porcentual = self.tasa_interes, valor_final = self.intereses, tiempo_deuda = self.tiempo_1, intervalo_tiempo = self.cronograma_1, tiempo_deuda_2 = self.tiempo_2, intervalo_tiempo_2 = self.cronograma_2)
        if (self.operacion == "la tasa de interes"):
            return calculos.hallar_interes(valor_inicial_deuda= self.capital, valor_final = self.intereses, tiempo_deuda = self.tiempo_1, intervalo_tiempo = self.cronograma_1, tiempo_deuda_2 = self.tiempo_2, intervalo_tiempo_2 = self.cronograma_2)
        if (self.operacion == "el tiempo"):
            return calculos.hallar_tiempo(valor_inicial_deuda= self.capital, valor_final = self.intereses, interes_porcentual = self.tasa_interes)
        if (self.operacion == "los intereses"):
            return calculos.hallar_valor_final(interes_porcentual = self.tasa_interes, valor_inicial_deuda = self.capital, tiempo_deuda = self.tiempo_1, intervalo_tiempo = self.cronograma_1, tiempo_deuda_2 = self.tiempo_2, intervalo_tiempo_2 = self.cronograma_2)






if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MyWindow()
    window.show()
    sys.exit(app.exec_())

    



