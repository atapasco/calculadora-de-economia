class InteresSimple:
    
    def hallar_valor_final(self, interes_porcentual, valor_inicial_deuda, tiempo_deuda, intervalo_tiempo, tiempo_deuda_2, intervalo_tiempo_2):

        tiempo_deuda = self.tiempo_deuda(intervalo_tiempo, tiempo_deuda, tiempo_deuda_2, intervalo_tiempo_2)
        return valor_inicial_deuda * (interes_porcentual / 100) * tiempo_deuda

    
    def hallar_tiempo(self, valor_final, interes_porcentual, valor_inicial_deuda):
        return valor_final / (valor_inicial_deuda * (interes_porcentual / 100))

    def hallar_valor_inicial(self, interes_porcentual, valor_final, tiempo_deuda, intervalo_tiempo, tiempo_deuda_2, intervalo_tiempo_2):

        tiempo_deuda = self.tiempo_deuda(intervalo_tiempo, tiempo_deuda, tiempo_deuda_2, intervalo_tiempo_2)
        return valor_final / ((interes_porcentual / 100) * tiempo_deuda)

    def hallar_interes(self, valor_inicial_deuda, valor_final, tiempo_deuda, intervalo_tiempo, tiempo_deuda_2, intervalo_tiempo_2):

        tiempo_deuda = self.tiempo_deuda(intervalo_tiempo, tiempo_deuda, tiempo_deuda_2, intervalo_tiempo_2)
        return valor_final / (valor_inicial_deuda * tiempo_deuda)
        

    def tiempo_deuda(self, intervalo_tiempo, tiempo_deuda_1, tiempo_deuda_2, intervalo_tiempo_2):

        if (tiempo_deuda_2 != 0):
            numero_interacciones = 2
        else:
            numero_interacciones = 1

        tiempo_final = 0
        for i in range(numero_interacciones): 
            if (intervalo_tiempo == "dias"):
                tiempo_final = (tiempo_deuda_1 / 365) + tiempo_final
            if (intervalo_tiempo == "meses"):
                tiempo_final = (tiempo_deuda_1 / 12) + tiempo_final
            if (intervalo_tiempo == "a\u00f1os"):
                tiempo_final = tiempo_deuda_1 + tiempo_final
            if (intervalo_tiempo == "trimestres"):
                tiempo_final = ((tiempo_deuda_1 * 3) / 12 ) + tiempo_final
            if (intervalo_tiempo == "semestres"):
                tiempo_final = ((tiempo_deuda_1 * 6) / 12) + tiempo_final
            if (intervalo_tiempo == "semanas"):
                tiempo_final = ((tiempo_deuda_1 * 7) / 365) + tiempo_final

            intervalo_tiempo = intervalo_tiempo_2
            tiempo_deuda_1 = tiempo_deuda_2
        return tiempo_final
    
